package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    // Update the password if your MySQL local server has one (default in XAMPP is empty "")
    private static final String URL = "jdbc:mysql://localhost:3306/coworking_db";
    private static final String USER = "root";
    private static final String PASSWORD = "#justhappy123"; 

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}